﻿namespace TrainingProject.Domain
{
    public class EventsTags
    {
        public Event Event { get; set; }
        public int EventId { get; set; }
        public Tag Tag { get; set; }
        public int TagId { get; set; }
    }
}
