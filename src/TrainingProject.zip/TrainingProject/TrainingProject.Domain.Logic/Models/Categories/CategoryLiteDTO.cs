﻿namespace TrainingProject.DomainLogic.Models.Categories
{
    public class CategoryLiteDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
