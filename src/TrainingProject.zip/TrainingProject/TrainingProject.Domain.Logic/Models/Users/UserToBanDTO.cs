﻿namespace TrainingProject.DomainLogic.Models.Users
{
    public class UserToBanDTO
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public bool IsBanned { get; set; }
    }
}
