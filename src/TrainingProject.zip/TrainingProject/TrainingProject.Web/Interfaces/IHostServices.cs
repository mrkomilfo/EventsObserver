﻿namespace TrainingProject.Web.Interfaces
{
    public interface IHostServices
    {
        public string GetHostPath();
    }
}
