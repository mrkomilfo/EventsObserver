﻿using Microsoft.AspNetCore.SignalR;

namespace TrainingProject.Web.Services
{
    public class CustomUserIdProvider : IUserIdProvider
    {
        public virtual string GetUserId(HubConnectionContext connection)
        {
            return connection.User?.Identity.Name;
        }
    }
}
